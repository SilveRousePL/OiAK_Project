package me.pogostick29dev.pro;

/**
 * Represents a variable type.
 */
public enum BuiltInType implements Type {

	STRING, INTEGER, VOID
}